---
title: Mentor Matching Service
summary: Allows mentors and mentees to be automatically matched based on form response. Utilized React for frontend, Python for the backend, created RESTful APIs using Flask and stored data in Firebase.
tags:
  - all
  - python
date: "2020-06-27T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: https://github.com/acmutd/mentor-matching-service

image:
  caption: matching service
  focal_point: Smart
---
